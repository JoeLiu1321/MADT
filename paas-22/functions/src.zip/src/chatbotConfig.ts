export const chatbot = "智能客服"

export const LINE = {
    channelId: "1649586736",
    channelSecret: "d302bfd9616f975ca87c8aa921640a8b",
    // channelAccessToken:"9gGojsrM36023RVcASaXoVUwNJrWJ0GsGty3fYmwWlORH7L+xVVzJfQiQbw/QaRGMWb+oHG8LbEjYjz4pGWTPkTcff2dPLkfM4mUIDV2awyEnTJTWLH+exWp3ayrbIT34ZXubtXCnpM5AT/8tb+eRAdB04t89/1O/w1cDnyilFU="
}
export const WECHAT = {
    appid: "<your_appid>",
    appSecret: "<your_appSecret>",
    token: "<your_token>",
    checkSignature: true
}